const MINIMAX_KEY = "sk-api-gwEUNeu7QBjvnngKiDVDXucEs7my2NAnvmlCGLD4XpM5KBZzGRuhXUwRjjhsYREfkqyQvIsGoy7Kcsg8gr7dXKUf7GTJHFGGZtoBKnbwZ0QP5ZB0NWDk9c0";
const GROUP_ID = "2024997704433676596";

const PRESET_VOICES = [
  { id: "moss_audio_7c5467e5-0fbd-11f1-a2d4-8609e701aa01", name: "Olga" },
  { id: "moss_audio_745e60fa-28b7-11f1-bd1c-42ad608c28be", name: "Mari" },
  { id: "moss_audio_743676dd-1862-11f1-a741-d68e15ebe5cd", name: "Katia" },
  { id: "moss_audio_0490f0b2-27e6-11f1-bd1c-42ad608c28be", name: "Ksenomorph" },
];

// --- Состояние ---
let customVoices = []; // [{ name, id }]
let audioFiles = [null, null, null]; // 3 файла для клонирования

// --- DOM ---
const statusEl    = document.getElementById("status");
const btnSpeak    = document.getElementById("btn-speak");
const textInput   = document.getElementById("text-input");
const speedInput  = document.getElementById("speed");
const volumeInput = document.getElementById("volume");
const speedVal    = document.getElementById("speed-val");
const volumeVal   = document.getElementById("volume-val");
const voiceSelect = document.getElementById("voice-select");
const addPanel    = document.getElementById("add-voice-panel");
const btnAdd      = document.getElementById("btn-add-voice");
const btnCancel   = document.getElementById("btn-cancel-clone");
const btnClone    = document.getElementById("btn-do-clone");
const voiceNameInput = document.getElementById("voice-name-input");

// ===================== ИНИЦИАЛИЗАЦИЯ =====================

chrome.storage.local.get(["voiceId", "speed", "volume", "lastText", "customVoices"], (data) => {
  customVoices = data.customVoices || [];
  renderCustomVoices();

  if (data.speed) {
    speedInput.value = data.speed;
    speedVal.textContent = parseFloat(data.speed).toFixed(1) + "x";
  }
  if (data.volume) {
    volumeInput.value = data.volume;
    volumeVal.textContent = parseFloat(data.volume).toFixed(1);
  }
  if (data.lastText) {
    textInput.value = data.lastText;
  }
  if (data.voiceId) {
    voiceSelect.value = data.voiceId;
  }
});

// ===================== ГОЛОСА =====================

function renderCustomVoices() {
  // Удаляем старые кастомные опции (оставляем первые 4 — пресеты)
  while (voiceSelect.options.length > PRESET_VOICES.length) {
    voiceSelect.remove(PRESET_VOICES.length);
  }

  // Добавляем разделитель если есть кастомные
  if (customVoices.length > 0) {
    const sep = document.createElement("option");
    sep.disabled = true;
    sep.textContent = "── Мои голоса ──";
    voiceSelect.appendChild(sep);

    for (const cv of customVoices) {
      const opt = document.createElement("option");
      opt.value = cv.id;
      opt.textContent = "👤 " + cv.name;
      voiceSelect.appendChild(opt);
    }
  }
}

voiceSelect.addEventListener("change", () => {
  chrome.storage.local.set({ voiceId: voiceSelect.value });
});

// ===================== ПАНЕЛЬ ДОБАВЛЕНИЯ ГОЛОСА =====================

btnAdd.addEventListener("click", () => {
  addPanel.style.display = addPanel.style.display === "none" ? "block" : "none";
});

btnCancel.addEventListener("click", () => {
  resetClonePanel();
  addPanel.style.display = "none";
});

// Файловые слоты
for (let i = 0; i < 3; i++) {
  const slotBtn = document.querySelector(`.file-slot-btn[data-slot="${i}"]`);
  const fileInput = document.getElementById(`file-${i}`);

  slotBtn.addEventListener("click", () => fileInput.click());

  fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    if (!file) return;
    audioFiles[i] = file;

    document.getElementById(`label-${i}`).textContent = file.name;
    document.getElementById(`label-${i}`).className = "file-slot-label filled";
    document.getElementById(`num-${i}`).className = "file-slot-num done";

    // Активируем кнопку если все 3 файла и есть название
    updateCloneButton();
  });
}

voiceNameInput.addEventListener("input", updateCloneButton);

function updateCloneButton() {
  const allFiles = audioFiles.every(f => f !== null);
  const hasName = voiceNameInput.value.trim().length > 0;
  btnClone.disabled = !(allFiles && hasName);
}

function resetClonePanel() {
  audioFiles = [null, null, null];
  voiceNameInput.value = "";
  for (let i = 0; i < 3; i++) {
    document.getElementById(`label-${i}`).textContent = `Аудио файл #${i + 1} (15–30 сек)`;
    document.getElementById(`label-${i}`).className = "file-slot-label";
    document.getElementById(`num-${i}`).className = "file-slot-num";
    document.getElementById(`file-${i}`).value = "";
  }
  btnClone.disabled = true;
}

// ===================== КЛОНИРОВАНИЕ ГОЛОСА =====================

btnClone.addEventListener("click", async () => {
  const voiceName = voiceNameInput.value.trim();
  if (!voiceName || audioFiles.some(f => !f)) return;

  btnClone.disabled = true;
  setStatus("Объединяю аудио...");

  try {
    // 1. Читаем все 3 файла как ArrayBuffer и склеиваем
    const buffers = await Promise.all(audioFiles.map(f => f.arrayBuffer()));
    const totalLength = buffers.reduce((sum, b) => sum + b.byteLength, 0);
    const merged = new Uint8Array(totalLength);
    let offset = 0;
    for (const buf of buffers) {
      merged.set(new Uint8Array(buf), offset);
      offset += buf.byteLength;
    }
    const mergedBlob = new Blob([merged], { type: "audio/mpeg" });

    // 2. Загружаем на MiniMax Files API
    setStatus("Загружаю на MiniMax...");
    const formData = new FormData();
    formData.append("file", mergedBlob, `voice_clone_${Date.now()}.mp3`);
    formData.append("purpose", "voice_clone");

    const uploadRes = await fetch(
      `https://api.minimax.io/v1/files/upload?GroupId=${GROUP_ID}`,
      {
        method: "POST",
        headers: { "Authorization": `Bearer ${MINIMAX_KEY}` },
        body: formData
      }
    );
    const uploadData = await uploadRes.json();
    if (!uploadData?.file?.file_id) {
      throw new Error("Ошибка загрузки файла: " + JSON.stringify(uploadData));
    }
    const fileId = uploadData.file.file_id;

    // 3. Клонируем голос
    setStatus("Создаю голос...");
    const voiceId = `cv_ext_${Date.now()}`;
    const cloneRes = await fetch(
      `https://api.minimax.io/v1/voice_clone?GroupId=${GROUP_ID}`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${MINIMAX_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ file_id: fileId, voice_id: voiceId })
      }
    );
    const cloneData = await cloneRes.json();
    if (cloneRes.status !== 200 && !cloneData?.base_resp) {
      throw new Error("Ошибка клонирования: " + JSON.stringify(cloneData));
    }

    // 4. Сохраняем в storage и обновляем список
    customVoices.push({ name: voiceName, id: voiceId });
    chrome.storage.local.set({ customVoices });
    renderCustomVoices();

    // Выбираем новый голос
    voiceSelect.value = voiceId;
    chrome.storage.local.set({ voiceId: voiceId });

    setStatus(`Голос "${voiceName}" создан!`, "ok");
    resetClonePanel();
    addPanel.style.display = "none";

  } catch (err) {
    setStatus("Ошибка: " + err.message, "error");
    btnClone.disabled = false;
  }
});

// ===================== СЛАЙДЕРЫ =====================

speedInput.addEventListener("input", () => {
  const v = parseFloat(speedInput.value).toFixed(1);
  speedVal.textContent = v + "x";
  chrome.storage.local.set({ speed: v });
});

volumeInput.addEventListener("input", () => {
  const v = parseFloat(volumeInput.value).toFixed(1);
  volumeVal.textContent = v;
  chrome.storage.local.set({ volume: v });
});

textInput.addEventListener("input", () => {
  chrome.storage.local.set({ lastText: textInput.value });
});

// ===================== ГЕНЕРАЦИЯ И ЗАГРУЗКА =====================

btnSpeak.addEventListener("click", async () => {
  const text = textInput.value.trim();
  if (!text) { setStatus("Введите текст", "error"); return; }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes("alpha.date")) {
    setStatus("Откройте alpha.date", "error");
    return;
  }

  btnSpeak.disabled = true;
  setStatus("Генерирую аудио...");

  try {
    const speed = parseFloat(speedInput.value);
    const vol   = parseFloat(volumeInput.value);
    const voiceId = voiceSelect.value;

    const res = await fetch(
      `https://api.minimax.io/v1/t2a_v2?GroupId=${GROUP_ID}`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${MINIMAX_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "speech-01-turbo",
          text,
          stream: false,
          voice_setting: {
            voice_id: voiceId,
            speed: Math.round(speed * 10) / 10,
            vol:   Math.round(vol   * 10) / 10,
            pitch: 0
          },
          audio_setting: {
            sample_rate: 32000,
            bitrate: 128000,
            format: "mp3",
            channel: 1
          }
        })
      }
    );

    const data = await res.json();
    if (data?.base_resp?.status_code !== 0) {
      throw new Error(data?.base_resp?.status_msg || "Ошибка API");
    }

    const hexAudio = data?.data?.audio;
    if (!hexAudio) throw new Error("Нет аудио в ответе");

    const bytes = new Uint8Array(hexAudio.match(/.{1,2}/g).map(b => parseInt(b, 16)));

    setStatus("Загружаю на сайт...");

    const result = await chrome.tabs.sendMessage(tab.id, {
      type: "UPLOAD_AUDIO",
      bytes: Array.from(bytes),
      filename: `voice_${Date.now()}.mp3`
    });

    if (result?.ok) {
      setStatus("Файл загружен!", "ok");
    } else {
      throw new Error(result?.error || "Не удалось загрузить");
    }

  } catch (err) {
    setStatus("Ошибка: " + err.message, "error");
  } finally {
    btnSpeak.disabled = false;
  }
});

function setStatus(msg, type = "") {
  statusEl.textContent = msg;
  statusEl.className = type;
}
