// ISOLATED world on minimax.io
// 1. Saves WS URL to storage when bridge posts it
// 2. Relays GENERATE_TTS from background → MAIN world → back

window.addEventListener("message", event => {
  if (event.source !== window) return;
  if (!event.data) return;

  if (event.data.type === "TTS_EXT_WS_URL") {
    const url = event.data.url;
    if (url) chrome.storage.local.set({ minimaxWsUrl: url });
  }
});

// Receive MINIMAX_GENERATE from background.js, forward to minimax-bridge.js (MAIN world)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "MINIMAX_GENERATE") return;

  const requestId = Date.now().toString() + Math.random();

  // Forward to MAIN world (destructure to avoid msg.type overwriting TTS_EXT_GENERATE)
  const { text, voiceId, speed, vol } = msg;
  window.postMessage({ type: "TTS_EXT_GENERATE", text, voiceId, speed, vol, requestId }, "*");

  // Wait for response from MAIN world
  const timeout = setTimeout(() => {
    window.removeEventListener("message", onAudio);
    sendResponse({ error: "Таймаут ожидания аудио" });
  }, 32000);

  function onAudio(event) {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== "TTS_EXT_AUDIO") return;
    if (event.data.requestId !== requestId) return;

    clearTimeout(timeout);
    window.removeEventListener("message", onAudio);

    if (event.data.error) {
      sendResponse({ error: event.data.error });
    } else {
      sendResponse({ hexAudio: event.data.hexAudio });
    }
  }

  window.addEventListener("message", onAudio);
  return true; // keep sendResponse open
});
