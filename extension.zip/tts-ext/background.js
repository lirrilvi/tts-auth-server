// Routes TTS generation requests: alpha.date content.js → minimax.io tab → back
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GENERATE_TTS") {
    handleGenerateTTS(msg).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
});

async function handleGenerateTTS({ text, voiceId, speed, vol }) {
  // Find existing minimax.io tab
  let tabs = await chrome.tabs.query({ url: ["https://www.minimax.io/*", "https://minimax.io/*"] });

  let tab = tabs[0];

  if (!tab) {
    // Open minimax.io silently in background
    tab = await chrome.tabs.create({ url: "https://www.minimax.io/audio/text-to-speech", active: false });
    await new Promise(resolve => {
      function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      }
      chrome.tabs.onUpdated.addListener(listener);
    });
    // Give content scripts time to initialise
    await new Promise(r => setTimeout(r, 2500));
  }

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Таймаут 35с — зайди на minimax.io и сгенерируй аудио хотя бы раз")), 35000);

    chrome.tabs.sendMessage(tab.id, { type: "MINIMAX_GENERATE", text, voiceId, speed, vol }, response => {
      clearTimeout(timeout);
      if (chrome.runtime.lastError) {
        reject(new Error("Ошибка связи с minimax.io: " + chrome.runtime.lastError.message));
      } else if (response?.error) {
        reject(new Error(response.error));
      } else {
        resolve(response);
      }
    });
  });
}
