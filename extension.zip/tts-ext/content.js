const MINIMAX_KEY  = "sk-api-gwEUNeu7QBjvnngKiDVDXucEs7my2NAnvmlCGLD4XpM5KBZzGRuhXUwRjjhsYREfkqyQvIsGoy7Kcsg8gr7dXKUf7GTJHFGGZtoBKnbwZ0QP5ZB0NWDk9c0";
const GROUP_ID     = "2024997704433676596";
const AUTH_SERVER  = "https://web-production-054d12.up.railway.app";
const TOKEN_TTL_MS = 12 * 60 * 60 * 1000;

const PRESET_VOICES = [
  { id: "moss_audio_7c5467e5-0fbd-11f1-a2d4-8609e701aa01", name: "Olga" },
  { id: "moss_audio_745e60fa-28b7-11f1-bd1c-42ad608c28be", name: "Mari" },
  { id: "moss_audio_743676dd-1862-11f1-a741-d68e15ebe5cd", name: "Katia" },
  { id: "moss_audio_0490f0b2-27e6-11f1-bd1c-42ad608c28be", name: "Ksenomorph" },
];

let customVoices       = [];
let audioFiles         = [null, null, null];
let panelOpen          = false;
let generatedBlob      = null;
let previewAudio       = null;
let isPlaying          = false;
let activeTab          = "audio";
let widgetBlob         = null;
let calcType           = "credits";
let calcPkg            = { cr: 45, price: 13 };
let lastRightClickedEl = null; // element right-clicked for in-place blur

// Track the element that was right-clicked
document.addEventListener("contextmenu", e => {
  const el = e.target.closest("img, video") || e.target;
  lastRightClickedEl = el;
}, true);

// ─── Styles ───────────────────────────────────────────────────────────────────
const style = document.createElement("style");
style.textContent = `
  #tts-btn {
    position: fixed; top: 8px; right: 248px;
    width: 38px; height: 38px; border-radius: 50%;
    background: #3dba6e; border: none; cursor: pointer;
    z-index: 99999; display: flex; align-items: center; justify-content: center;
    box-shadow: 0 2px 8px rgba(0,0,0,.35);
    transition: background .15s, transform .15s;
    font-size: 19px; line-height: 1; padding: 0;
  }
  #tts-btn:hover { background: #35a860; transform: scale(1.08); }

  #tts-panel {
    position: fixed; top: 56px; right: 14px; width: 348px;
    background: #141414; border: 1px solid #2a2a2a; border-radius: 14px;
    padding: 15px; z-index: 99998;
    box-shadow: 0 8px 32px rgba(0,0,0,.55);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px; color: #e8e8e8; display: none;
  }
  #tts-panel * { box-sizing: border-box; margin: 0; padding: 0; }

  /* ── Tabs ── */
  .tts-tabs { display: flex; gap: 5px; margin-bottom: 14px; }
  .tts-tab {
    flex: 1; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 9px; color: #555; font-size: 14px; padding: 11px 4px;
    cursor: pointer; transition: all .15s; white-space: nowrap;
  }
  .tts-tab.active { background: #1a2e22; border-color: #3dba6e; color: #3dba6e; font-weight: 600; }
  .tts-tab:hover:not(.active) { color: #888; background: #202020; }

  /* ── Shared ── */
  .tts-label { display: block; color: #555; font-size: 12px; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 7px; }
  .tts-divider { border: none; border-top: 1px solid #1e1e1e; margin: 11px 0; }

  .tts-btn-green {
    width: 100%; background: #3dba6e; color: #fff; border: none;
    border-radius: 8px; padding: 13px; font-size: 15px; font-weight: 600;
    cursor: pointer; transition: background .15s; margin-bottom: 9px;
  }
  .tts-btn-green:hover { background: #35a860; }
  .tts-btn-green:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }

  .tts-status { font-size: 12px; color: #444; min-height: 16px; text-align: center; }
  .tts-status.ok    { color: #3dba6e; }
  .tts-status.error { color: #e05555; }
  .tts-status.warn  { color: #c8a020; }

  /* ── Audio tab ── */
  .tts-voice-row { display: flex; gap: 6px; align-items: center; margin-bottom: 10px; }
  #tts-voice-select {
    flex: 1; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #e8e8e8; padding: 7px 28px 7px 10px;
    font-size: 13px; outline: none; cursor: pointer; appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='5'%3E%3Cpath d='M0 0l4.5 5L9 0z' fill='%23555'/%3E%3C/svg%3E");
    background-repeat: no-repeat; background-position: right 9px center;
  }
  #tts-voice-select:focus { border-color: #3dba6e; }
  #tts-btn-add-voice {
    background: transparent; border: 1px solid #2e2e2e; border-radius: 8px;
    color: #3dba6e; padding: 6px 9px; font-size: 11px; cursor: pointer;
    white-space: nowrap; transition: all .15s;
  }
  #tts-btn-add-voice:hover { background: #1a2e22; border-color: #3dba6e; }
  .tts-slider-row { display: flex; align-items: center; gap: 7px; margin-bottom: 7px; }
  .tts-slider-lbl { width: 65px; color: #555; font-size: 11px; flex-shrink: 0; }
  .tts-slider-row input[type=range] { flex: 1; accent-color: #3dba6e; }
  .tts-slider-val { width: 30px; text-align: right; color: #888; font-size: 11px; font-variant-numeric: tabular-nums; }
  #tts-textarea {
    width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #e8e8e8; font-size: 13px;
    padding: 8px 10px; resize: vertical; min-height: 72px;
    outline: none; margin-bottom: 9px; font-family: inherit; line-height: 1.5;
  }
  #tts-textarea:focus { border-color: #3dba6e; }
  #tts-textarea::placeholder { color: #333; }
  #tts-player {
    display: none; background: #0f0f0f; border: 1px solid #222;
    border-radius: 10px; padding: 10px 12px; margin-bottom: 8px;
  }
  #tts-player-label { font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 8px; }
  #tts-progress-wrap { position: relative; height: 3px; background: #222; border-radius: 2px; margin-bottom: 8px; cursor: pointer; }
  #tts-progress-bar { height: 100%; background: #3dba6e; border-radius: 2px; width: 0%; pointer-events: none; }
  #tts-time { font-size: 10px; color: #555; margin-bottom: 8px; font-variant-numeric: tabular-nums; }
  .tts-player-btns { display: flex; gap: 6px; }
  #tts-btn-play {
    flex: 1; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 7px; color: #e8e8e8; font-size: 12px; padding: 7px; cursor: pointer; transition: all .15s;
  }
  #tts-btn-play:hover { background: #242424; }
  #tts-btn-redo {
    flex: 1; background: transparent; border: 1px solid #2e2e2e;
    border-radius: 7px; color: #888; font-size: 12px; padding: 7px; cursor: pointer; transition: all .15s;
  }
  #tts-btn-redo:hover { border-color: #555; color: #ccc; }
  #tts-btn-upload {
    flex: 1.5; background: #3dba6e; border: none;
    border-radius: 7px; color: #fff; font-size: 12px; font-weight: 600;
    padding: 7px; cursor: pointer; transition: background .15s;
  }
  #tts-btn-upload:hover { background: #35a860; }
  #tts-btn-upload:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }
  #tts-token-info { font-size: 10px; color: #3dba6e; text-align: right; margin-bottom: 6px; display: none; }

  /* Voice clone panel */
  #tts-add-panel { background: #0f0f0f; border: 1px solid #222; border-radius: 10px; padding: 11px; margin-bottom: 10px; display: none; }
  #tts-add-panel h3 { font-size: 12px; font-weight: 600; color: #bbb; margin-bottom: 9px; }
  #tts-voice-name { width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 7px; color: #e8e8e8; font-size: 12px; padding: 6px 9px; outline: none; margin-bottom: 8px; font-family: inherit; }
  #tts-voice-name:focus { border-color: #3dba6e; }
  #tts-voice-name::placeholder { color: #333; }
  .tts-file-slot { display: flex; align-items: center; gap: 7px; margin-bottom: 5px; }
  .tts-slot-num { width: 18px; height: 18px; border-radius: 50%; background: #1e1e1e; border: 1px solid #2e2e2e; color: #555; font-size: 9px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .tts-slot-num.done { background: #1a3a2a; border-color: #3dba6e; color: #3dba6e; }
  .tts-slot-lbl { flex: 1; color: #444; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tts-slot-lbl.filled { color: #999; }
  .tts-slot-pick { background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 6px; color: #777; font-size: 10px; padding: 3px 7px; cursor: pointer; flex-shrink: 0; }
  .tts-slot-pick:hover { background: #242424; color: #bbb; }
  .tts-clone-hint { font-size: 10px; color: #333; margin: 6px 0 8px; line-height: 1.4; }
  .tts-panel-btns { display: flex; gap: 5px; }
  .tts-btn-cancel { flex: 1; background: transparent; border: 1px solid #2e2e2e; border-radius: 7px; color: #555; font-size: 11px; padding: 7px; cursor: pointer; }
  .tts-btn-cancel:hover { color: #999; border-color: #444; }
  .tts-btn-clone { flex: 2; background: #3dba6e; border: none; border-radius: 7px; color: #fff; font-size: 11px; font-weight: 600; padding: 7px; cursor: pointer; }
  .tts-btn-clone:hover { background: #35a860; }
  .tts-btn-clone:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }

  /* Auth screen */
  #tts-auth-screen { display: none; text-align: center; padding: 6px 0 2px; }
  #tts-auth-screen p { font-size: 12px; color: #888; margin-bottom: 10px; line-height: 1.5; }
  #tts-auth-screen a { color: #3dba6e; }
  #tts-token-input {
    width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #e8e8e8; font-size: 15px; font-weight: 600;
    padding: 8px 10px; outline: none; text-align: center;
    letter-spacing: 2px; text-transform: uppercase; margin-bottom: 8px; font-family: monospace;
  }
  #tts-token-input:focus { border-color: #3dba6e; }
  #tts-token-input::placeholder { font-weight: 400; letter-spacing: 0; font-size: 12px; text-transform: none; color: #333; }
  #tts-btn-auth {
    width: 100%; background: #3dba6e; color: #fff; border: none;
    border-radius: 8px; padding: 9px; font-size: 13px; font-weight: 600; cursor: pointer; transition: background .15s;
  }
  #tts-btn-auth:hover { background: #35a860; }
  #tts-btn-auth:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }
  #tts-auth-status { font-size: 11px; margin-top: 6px; min-height: 14px; }
  #tts-auth-status.error { color: #e05555; }
  #tts-auth-status.ok    { color: #3dba6e; }

  /* ── Widget tab ── */
  #tts-widget-num {
    width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 8px;
    color: #e8e8e8; font-size: 40px; font-weight: 700; padding: 12px;
    outline: none; text-align: center; margin-bottom: 11px; font-family: inherit;
  }
  #tts-widget-num:focus { border-color: #3dba6e; }
  #tts-widget-preview {
    display: none; width: 120px; height: 120px;
    border-radius: 10px; margin: 0 auto 10px;
    border: 1px solid #1e1e1e; object-fit: contain;
  }

  /* ── Calc tab ── */
  .tts-seg { display: flex; gap: 4px; margin-bottom: 10px; }
  .tts-seg-btn {
    flex: 1; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #555; font-size: 14px; padding: 11px 4px;
    cursor: pointer; transition: all .15s; white-space: nowrap;
  }
  .tts-seg-btn.active { background: #1a2e22; border-color: #3dba6e; color: #3dba6e; font-weight: 600; }
  .tts-seg-btn:hover:not(.active) { color: #888; background: #202020; }
  #tts-calc-val {
    width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 8px;
    color: #e8e8e8; font-size: 34px; font-weight: 700; padding: 12px 10px;
    outline: none; text-align: center; margin-bottom: 11px; font-family: inherit;
  }
  #tts-calc-val:focus { border-color: #3dba6e; }
  #tts-calc-val::placeholder { font-size: 14px; font-weight: 400; color: #333; }
  .tts-pkg-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; margin-bottom: 12px; }
  .tts-pkg-btn {
    background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 8px;
    color: #555; font-size: 14px; padding: 11px 5px; cursor: pointer; transition: all .15s;
  }
  .tts-pkg-btn.active { background: #1a2e22; border-color: #3dba6e; color: #3dba6e; font-weight: 600; }
  .tts-pkg-btn:hover:not(.active) { color: #888; background: #202020; }
  #tts-calc-result {
    background: #0f0f0f; border: 1px solid #1e1e1e; border-radius: 10px;
    padding: 12px 16px; font-size: 15px; line-height: 2.6; color: #555;
  }
  #tts-calc-result .calc-row { display: flex; justify-content: space-between; align-items: center; }
  #tts-calc-result .calc-val { color: #e8e8e8; font-weight: 700; font-size: 19px; font-variant-numeric: tabular-nums; }

  /* ── Blur toast notification ── */
  #tts-blur-toast {
    position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
    background: #1a2e22; border: 1px solid #3dba6e; border-radius: 10px;
    color: #3dba6e; font-size: 12px; padding: 9px 18px;
    z-index: 999999; display: none; white-space: nowrap;
    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    box-shadow: 0 4px 16px rgba(0,0,0,.5);
  }
  #tts-blur-toast.error { background: #2e1a1a; border-color: #e05555; color: #e05555; }
`;
document.head.appendChild(style);

// ─── Toggle button ─────────────────────────────────────────────────────────────
const btn = document.createElement("button");
btn.id = "tts-btn"; btn.title = "TTS Voice"; btn.innerHTML = "🗣";
document.body.appendChild(btn);

// ─── Blur toast ────────────────────────────────────────────────────────────────
const blurToast = document.createElement("div");
blurToast.id = "tts-blur-toast";
document.body.appendChild(blurToast);

function showToast(msg, isErr = false, ms = 3000) {
  blurToast.textContent = msg;
  blurToast.className = isErr ? "error" : "";
  blurToast.style.display = "block";
  clearTimeout(blurToast._t);
  blurToast._t = setTimeout(() => { blurToast.style.display = "none"; }, ms);
}

// ─── Panel ─────────────────────────────────────────────────────────────────────
const panel = document.createElement("div");
panel.id = "tts-panel";
panel.innerHTML = `
  <!-- Auth screen -->
  <div id="tts-auth-screen">
    <p>🔐 Введи код из Telegram-бота<br><small style="color:#555">Получи /token у бота</small></p>
    <input type="text" id="tts-token-input" placeholder="Введи код (напр. A3B7XK2P)" maxlength="12">
    <button id="tts-btn-auth">Войти</button>
    <div id="tts-auth-status"></div>
  </div>

  <!-- Main UI -->
  <div id="tts-main">
    <div id="tts-token-info"></div>

    <!-- Tab nav -->
    <div class="tts-tabs">
      <button class="tts-tab active" data-tab="audio">🎙 Аудио</button>
      <button class="tts-tab" data-tab="widget">⭕ Виджет</button>
      <button class="tts-tab" data-tab="calc">🧮 Калькулятор</button>
    </div>

    <!-- ══ AUDIO TAB ══ -->
    <div id="tts-tab-audio">
      <span class="tts-label">Голос</span>
      <div class="tts-voice-row">
        <select id="tts-voice-select"></select>
        <button id="tts-btn-add-voice">+ Add</button>
      </div>

      <div id="tts-add-panel">
        <h3>🎤 Новый голос</h3>
        <input type="text" id="tts-voice-name" placeholder="Название (напр. Alex)">
        <div id="tts-file-slots"></div>
        <p class="tts-clone-hint">MP3 / WAV · 15–30 сек · говорите чётко</p>
        <div class="tts-panel-btns">
          <button class="tts-btn-cancel" id="tts-cancel-clone">Отмена</button>
          <button class="tts-btn-clone" id="tts-do-clone" disabled>Создать голос</button>
        </div>
      </div>

      <hr class="tts-divider">

      <div class="tts-slider-row">
        <span class="tts-slider-lbl">Скорость</span>
        <input type="range" id="tts-speed" min="0.5" max="2.0" step="0.1" value="1.0">
        <span class="tts-slider-val" id="tts-speed-val">1.0x</span>
      </div>
      <div class="tts-slider-row">
        <span class="tts-slider-lbl">Громкость</span>
        <input type="range" id="tts-volume" min="0.2" max="3.0" step="0.1" value="1.0">
        <span class="tts-slider-val" id="tts-vol-val">1.0</span>
      </div>

      <hr class="tts-divider">

      <textarea id="tts-textarea" placeholder="Введите текст для озвучки..."></textarea>
      <button id="tts-btn-speak" class="tts-btn-green">▶ Сгенерировать</button>

      <div id="tts-player">
        <div id="tts-player-label">Превью</div>
        <div id="tts-progress-wrap"><div id="tts-progress-bar"></div></div>
        <div id="tts-time">0:00 / 0:00</div>
        <div class="tts-player-btns">
          <button id="tts-btn-play">▶ Слушать</button>
          <button id="tts-btn-redo">🔄 Заново</button>
          <button id="tts-btn-upload">⬆ Загрузить</button>
        </div>
      </div>

      <div id="tts-status" class="tts-status"></div>
    </div><!-- /audio tab -->

    <!-- ══ WIDGET TAB ══ -->
    <div id="tts-tab-widget" style="display:none">
      <span class="tts-label">Процент (0 – 100)</span>
      <input type="number" id="tts-widget-num" min="0" max="100" value="75" placeholder="75">
      <img id="tts-widget-preview" alt="widget preview">
      <button id="tts-widget-draw" class="tts-btn-green" style="margin-bottom:6px">⭕ Нарисовать</button>
      <button id="tts-widget-upload" class="tts-btn-green" disabled style="background:#1e3a2a;color:#3dba6e;border:1px solid #3dba6e">⬆ Загрузить на сайт</button>
      <div id="tts-widget-status" class="tts-status" style="margin-top:6px"></div>
    </div><!-- /widget tab -->

    <!-- ══ CALC TAB ══ -->
    <div id="tts-tab-calc" style="display:none">
      <span class="tts-label">Что вводите?</span>
      <div class="tts-seg" id="tts-type-seg">
        <button class="tts-seg-btn active" data-type="credits">💰 Кредиты</button>
        <button class="tts-seg-btn" data-type="balance">💳 Баланс</button>
        <button class="tts-seg-btn" data-type="price">👨 Цена ($)</button>
      </div>
      <input type="number" id="tts-calc-val" placeholder="Введите значение">
      <span class="tts-label">Пакет</span>
      <div class="tts-pkg-grid" id="tts-pkg-grid">
        <button class="tts-pkg-btn active" data-cr="45"  data-price="13">45 cr / $13</button>
        <button class="tts-pkg-btn"        data-cr="85"  data-price="24">85 cr / $24</button>
        <button class="tts-pkg-btn"        data-cr="200" data-price="56">200 cr / $56</button>
        <button class="tts-pkg-btn"        data-cr="830" data-price="167">830 cr / $167</button>
      </div>
      <div id="tts-calc-result">
        <div class="calc-row"><span>💰 Кредиты</span><span class="calc-val" id="res-cr">—</span></div>
        <div class="calc-row"><span>💳 Баланс</span><span class="calc-val" id="res-bal">—</span></div>
        <div class="calc-row"><span>👨 Цена</span><span class="calc-val" id="res-price">—</span></div>
      </div>
    </div><!-- /calc tab -->

  </div><!-- #tts-main -->
`;
document.body.appendChild(panel);

// ─── Hidden file inputs for voice cloning ──────────────────────────────────────
const fileInputs = [0,1,2].map(i => {
  const inp = document.createElement("input");
  inp.type = "file"; inp.accept = "audio/*";
  inp.style.display = "none"; inp.id = `tts-file-${i}`;
  document.body.appendChild(inp);
  return inp;
});

const $ = id => document.getElementById(id);

// ─── Tab switching ─────────────────────────────────────────────────────────────
document.querySelectorAll(".tts-tab").forEach(tabBtn => {
  tabBtn.addEventListener("click", e => {
    e.stopPropagation();
    const tab = tabBtn.dataset.tab;
    activeTab = tab;
    document.querySelectorAll(".tts-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    ["audio","widget","calc"].forEach(t => {
      const el = $(`tts-tab-${t}`);
      if (el) el.style.display = t === tab ? "block" : "none";
    });
  });
});

// ─── Init ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get(["voiceId","speed","volume","lastText","customVoices"], data => {
  customVoices = data.customVoices || [];
  renderVoices();
  if (data.voiceId)  $("tts-voice-select").value = data.voiceId;
  if (data.speed)   { $("tts-speed").value = data.speed;   $("tts-speed-val").textContent  = parseFloat(data.speed).toFixed(1)+"x"; }
  if (data.volume)  { $("tts-volume").value = data.volume; $("tts-vol-val").textContent    = parseFloat(data.volume).toFixed(1); }
  if (data.lastText) $("tts-textarea").value = data.lastText;
});

buildFileSlots();

// ─── Auth ──────────────────────────────────────────────────────────────────────
function showAuthScreen() {
  $("tts-auth-screen").style.display = "block";
  $("tts-main").style.display = "none";
}
function showMainScreen() {
  $("tts-auth-screen").style.display = "none";
  $("tts-main").style.display = "block";
}

async function checkAuth() {
  const { ttsToken } = await new Promise(r => chrome.storage.local.get(["ttsToken"], r));
  if (!ttsToken) { showAuthScreen(); return; }
  try {
    const res  = await fetch(`${AUTH_SERVER}/api/validate`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: ttsToken })
    });
    const data = await res.json();
    if (data.ok) {
      showMainScreen();
      const info = $("tts-token-info");
      info.style.display = "block";
      info.textContent = `🔑 ${data.expires_msg || "Токен активен"}`;
    } else {
      chrome.storage.local.remove(["ttsToken","ttsTokenExpiry"]);
      showAuthScreen();
    }
  } catch {
    showMainScreen();
  }
}

$("tts-btn-auth").addEventListener("click", async e => {
  e.stopPropagation();
  const token = $("tts-token-input").value.trim().toUpperCase();
  if (!token) return;
  $("tts-btn-auth").disabled = true;
  $("tts-auth-status").textContent = "Проверяю...";
  $("tts-auth-status").className = "";
  try {
    const res  = await fetch(`${AUTH_SERVER}/api/validate`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token })
    });
    const data = await res.json();
    if (data.ok) {
      const expiry = Date.now() + TOKEN_TTL_MS;
      await new Promise(r => chrome.storage.local.set({ ttsToken: token, ttsTokenExpiry: expiry }, r));
      $("tts-auth-status").textContent = "✓ " + (data.expires_msg || "Авторизован");
      $("tts-auth-status").className = "ok";
      setTimeout(() => { showMainScreen(); checkAuth(); }, 800);
    } else {
      $("tts-auth-status").textContent = data.msg || "Неверный токен";
      $("tts-auth-status").className = "error";
      $("tts-btn-auth").disabled = false;
    }
  } catch {
    $("tts-auth-status").textContent = "Сервер недоступен";
    $("tts-auth-status").className = "error";
    $("tts-btn-auth").disabled = false;
  }
});

$("tts-token-input").addEventListener("keydown", e => { if (e.key === "Enter") $("tts-btn-auth").click(); });

// ─── Toggle panel ──────────────────────────────────────────────────────────────
btn.addEventListener("click", () => {
  panelOpen = !panelOpen;
  panel.style.display = panelOpen ? "block" : "none";
  if (panelOpen) checkAuth();
});

document.addEventListener("click", e => {
  if (panelOpen && !panel.contains(e.target) && e.target !== btn) {
    panelOpen = false;
    panel.style.display = "none";
  }
});

// ─── Voices ────────────────────────────────────────────────────────────────────
function renderVoices() {
  const sel = $("tts-voice-select"); sel.innerHTML = "";
  for (const v of PRESET_VOICES) {
    const o = document.createElement("option");
    o.value = v.id; o.textContent = v.name; sel.appendChild(o);
  }
  if (customVoices.length) {
    const sep = document.createElement("option"); sep.disabled = true; sep.textContent = "── Мои голоса ──"; sel.appendChild(sep);
    for (const cv of customVoices) {
      const o = document.createElement("option"); o.value = cv.id; o.textContent = "👤 " + cv.name; sel.appendChild(o);
    }
  }
}

$("tts-voice-select").addEventListener("change", () => chrome.storage.local.set({ voiceId: $("tts-voice-select").value }));

$("tts-btn-add-voice").addEventListener("click", e => {
  e.stopPropagation();
  const ap = $("tts-add-panel");
  ap.style.display = ap.style.display === "none" ? "block" : "none";
});
$("tts-cancel-clone").addEventListener("click", () => { resetClone(); $("tts-add-panel").style.display = "none"; });

function buildFileSlots() {
  const container = $("tts-file-slots"); if (!container) return;
  container.innerHTML = "";
  for (let i = 0; i < 3; i++) {
    const slot = document.createElement("div"); slot.className = "tts-file-slot";
    slot.innerHTML = `<div class="tts-slot-num" id="tts-num-${i}">${i+1}</div><span class="tts-slot-lbl" id="tts-lbl-${i}">Аудио #${i+1}</span><button class="tts-slot-pick" data-slot="${i}">Выбрать</button>`;
    container.appendChild(slot);
    slot.querySelector(".tts-slot-pick").addEventListener("click", e => { e.stopPropagation(); fileInputs[i].click(); });
    fileInputs[i].addEventListener("change", () => {
      const f = fileInputs[i].files[0]; if (!f) return;
      audioFiles[i] = f;
      $(`tts-lbl-${i}`).textContent = f.name; $(`tts-lbl-${i}`).className = "tts-slot-lbl filled";
      $(`tts-num-${i}`).className = "tts-slot-num done";
      updateCloneBtn();
    });
  }
}

$("tts-voice-name").addEventListener("input", updateCloneBtn);
function updateCloneBtn() {
  $("tts-do-clone").disabled = !(audioFiles.every(f => f !== null) && $("tts-voice-name").value.trim().length > 0);
}
function resetClone() {
  audioFiles = [null, null, null]; $("tts-voice-name").value = "";
  for (let i = 0; i < 3; i++) {
    $(`tts-lbl-${i}`).textContent = `Аудио #${i+1}`; $(`tts-lbl-${i}`).className = "tts-slot-lbl";
    $(`tts-num-${i}`).className = "tts-slot-num"; fileInputs[i].value = "";
  }
  $("tts-do-clone").disabled = true;
}

$("tts-do-clone").addEventListener("click", async e => {
  e.stopPropagation();
  const voiceName = $("tts-voice-name").value.trim();
  if (!voiceName || audioFiles.some(f => !f)) return;
  $("tts-do-clone").disabled = true; setStatus("Объединяю аудио...");
  try {
    const buffers = await Promise.all(audioFiles.map(f => f.arrayBuffer()));
    const total = buffers.reduce((s, b) => s + b.byteLength, 0);
    const merged = new Uint8Array(total); let offset = 0;
    for (const buf of buffers) { merged.set(new Uint8Array(buf), offset); offset += buf.byteLength; }
    const mergedBlob = new Blob([merged], { type: "audio/mpeg" });
    setStatus("Загружаю на MiniMax...");
    const form = new FormData();
    form.append("file", mergedBlob, `clone_${Date.now()}.mp3`);
    form.append("purpose", "voice_clone");
    const upRes  = await fetch(`https://api.minimax.io/v1/files/upload?GroupId=${GROUP_ID}`, { method: "POST", headers: { "Authorization": `Bearer ${MINIMAX_KEY}` }, body: form });
    const upData = await upRes.json();
    if (!upData?.file?.file_id) throw new Error("Ошибка загрузки: " + JSON.stringify(upData));
    setStatus("Создаю голос...");
    const voiceId = `cv_ext_${Date.now()}`;
    const clRes = await fetch(`https://api.minimax.io/v1/voice_clone?GroupId=${GROUP_ID}`, { method: "POST", headers: { "Authorization": `Bearer ${MINIMAX_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ file_id: upData.file.file_id, voice_id: voiceId }) });
    const clData = await clRes.json();
    if (!clRes.ok && !clData?.base_resp) throw new Error("Ошибка клонирования: " + JSON.stringify(clData));
    customVoices.push({ name: voiceName, id: voiceId });
    chrome.storage.local.set({ customVoices }); renderVoices();
    $("tts-voice-select").value = voiceId; chrome.storage.local.set({ voiceId });
    setStatus(`Голос "${voiceName}" создан!`, "ok"); resetClone();
    $("tts-add-panel").style.display = "none";
  } catch (err) { setStatus("Ошибка: " + err.message, "error"); $("tts-do-clone").disabled = false; }
});

// ─── Sliders ───────────────────────────────────────────────────────────────────
$("tts-speed").addEventListener("input", () => {
  const v = parseFloat($("tts-speed").value).toFixed(1);
  $("tts-speed-val").textContent = v + "x"; chrome.storage.local.set({ speed: v });
});
$("tts-volume").addEventListener("input", () => {
  const v = parseFloat($("tts-volume").value).toFixed(1);
  $("tts-vol-val").textContent = v; chrome.storage.local.set({ volume: v });
});
$("tts-textarea").addEventListener("input", () => chrome.storage.local.set({ lastText: $("tts-textarea").value }));

// ─── Generate TTS ──────────────────────────────────────────────────────────────
$("tts-btn-speak").addEventListener("click", e => { e.stopPropagation(); doGenerate(); });
$("tts-btn-redo").addEventListener("click",  e => { e.stopPropagation(); doGenerate(); });

async function doGenerate() {
  const text = $("tts-textarea").value.trim();
  if (!text) { setStatus("Введите текст", "error"); return; }
  stopPreview(); $("tts-player").style.display = "none";
  $("tts-btn-speak").disabled = true; setStatus("Генерирую аудио...");
  try {
    const speed = parseFloat($("tts-speed").value);
    const vol   = parseFloat($("tts-volume").value);
    const voiceId = $("tts-voice-select").value;
    const res = await fetch(`https://api.minimax.io/v1/t2a_v2?GroupId=${GROUP_ID}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${MINIMAX_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "speech-01-turbo", text, stream: false, voice_setting: { voice_id: voiceId, speed: Math.round(speed*10)/10, vol: Math.round(vol*10)/10, pitch: 0 }, audio_setting: { sample_rate: 32000, bitrate: 128000, format: "mp3", channel: 1 } })
    });
    const data = await res.json();
    if (data?.base_resp?.status_code !== 0) throw new Error(data?.base_resp?.status_msg || "Ошибка API");
    const hexAudio = data?.data?.audio; if (!hexAudio) throw new Error("Нет аудио в ответе");
    const bytes = new Uint8Array(hexAudio.match(/.{1,2}/g).map(b => parseInt(b, 16)));
    generatedBlob = new Blob([bytes], { type: "audio/mpeg" });
    setStatus("Готово — прослушай перед загрузкой", "ok"); showPlayer();
  } catch (err) { setStatus("Ошибка: " + err.message, "error"); }
  finally { $("tts-btn-speak").disabled = false; }
}

// ─── Player ────────────────────────────────────────────────────────────────────
function showPlayer() {
  $("tts-player").style.display = "block";
  $("tts-progress-bar").style.width = "0%"; $("tts-time").textContent = "0:00 / 0:00";
  updatePlayBtn(false);
}
function updatePlayBtn(playing) { isPlaying = playing; $("tts-btn-play").textContent = playing ? "⏸ Пауза" : "▶ Слушать"; }
function formatTime(s) { return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`; }
function stopPreview() { if (previewAudio) { previewAudio.pause(); previewAudio.src = ""; previewAudio = null; } isPlaying = false; }

$("tts-btn-play").addEventListener("click", e => {
  e.stopPropagation(); if (!generatedBlob) return;
  if (isPlaying && previewAudio) { previewAudio.pause(); updatePlayBtn(false); return; }
  if (previewAudio && previewAudio.paused) { previewAudio.play(); updatePlayBtn(true); return; }
  previewAudio = new Audio(URL.createObjectURL(generatedBlob));
  previewAudio.addEventListener("timeupdate", () => {
    if (!previewAudio?.duration) return;
    $("tts-progress-bar").style.width = (previewAudio.currentTime / previewAudio.duration * 100) + "%";
    $("tts-time").textContent = `${formatTime(previewAudio.currentTime)} / ${formatTime(previewAudio.duration)}`;
  });
  previewAudio.addEventListener("ended", () => { updatePlayBtn(false); $("tts-progress-bar").style.width = "0%"; });
  previewAudio.addEventListener("error",  () => { setStatus("Ошибка воспроизведения", "error"); updatePlayBtn(false); });
  previewAudio.play(); updatePlayBtn(true);
});

$("tts-progress-wrap").addEventListener("click", e => {
  if (!previewAudio?.duration) return;
  const rect = $("tts-progress-wrap").getBoundingClientRect();
  previewAudio.currentTime = ((e.clientX - rect.left) / rect.width) * previewAudio.duration;
});

// ─── Upload Audio ──────────────────────────────────────────────────────────────
$("tts-btn-upload").addEventListener("click", async e => {
  e.stopPropagation(); if (!generatedBlob) return;
  stopPreview(); $("tts-btn-upload").disabled = true; setStatus("Загружаю...");
  try {
    const file = new File([generatedBlob], `voice_${Date.now()}.mp3`, { type: "audio/mpeg" });
    let injected = injectFile(file);
    if (!injected) {
      const audioBtn = findAudioButton();
      if (audioBtn) { audioBtn.click(); setStatus("Открываю модал..."); injected = await waitAndInject(file, 4000); }
    }
    if (!injected) { setStatus("Нажми кнопку AUDIO на сайте, потом загрузи снова", "warn"); return; }
    setStatus("Добавляю...");
    const clicked = await waitAndClickAddAudio(3000);
    setStatus(clicked ? "✅ Загружено!" : "Нажми Add Audio вручную", clicked ? "ok" : "warn");
  } finally { $("tts-btn-upload").disabled = false; }
});

function findAudioButton() {
  const b = document.querySelector('button[data-testid="add-audio-btn"]');
  if (b && b.offsetParent !== null) return b;
  for (const el of document.querySelectorAll("button, div, span, a")) {
    const txt = (el.innerText || el.textContent || "").trim().toUpperCase();
    if (txt === "AUDIO" && el.offsetParent !== null) return el;
  }
  return null;
}

async function waitAndClickAddAudio(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    await new Promise(r => setTimeout(r, 200));
    const b = document.querySelector('div[data-testid="add-audio-btn"]');
    if (b && b.offsetParent !== null) { b.click(); return true; }
  }
  return false;
}

async function waitAndInject(file, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) { await new Promise(r => setTimeout(r, 200)); if (injectFile(file)) return true; }
  return false;
}

function injectFile(file) {
  const inputs = Array.from(document.querySelectorAll('input[type="file"]')).filter(inp => !inp.id.startsWith("tts-"));
  for (const inp of inputs) {
    try {
      const dt = new DataTransfer(); dt.items.add(file);
      const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "files");
      if (ns?.set) ns.set.call(inp, dt.files);
      inp.dispatchEvent(new Event("input",  { bubbles: true }));
      inp.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (_) {}
  }
  for (const el of document.querySelectorAll("*")) {
    const txt = (el.innerText || "").trim();
    if ((txt.includes("Drag & drop") || txt.includes("drag & drop")) && txt.length < 200) {
      const dt = new DataTransfer(); dt.items.add(file);
      for (const name of ["dragenter","dragover","drop"]) {
        const ev = new DragEvent(name, { bubbles: true, cancelable: true });
        Object.defineProperty(ev, "dataTransfer", { value: dt }); el.dispatchEvent(ev);
      }
      return true;
    }
  }
  return false;
}

function setStatus(msg, type = "") {
  const el = $("tts-status"); if (!el) return;
  el.textContent = msg; el.className = "tts-status" + (type ? " " + type : "");
}

// ─── WIDGET TAB ────────────────────────────────────────────────────────────────
function drawWidgetCanvas(percent) {
  const size = 800;
  const canvas = document.createElement("canvas");
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext("2d");
  const center = size / 2;
  const radius = size * 0.35;
  const strokeWidth = size * 0.08;

  // White background
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, size, size);

  // Gray background ring (no lineCap — flat edges)
  ctx.beginPath();
  ctx.arc(center, center, radius, 0, 2 * Math.PI);
  ctx.lineWidth = strokeWidth;
  ctx.strokeStyle = "#eeeeee";
  ctx.stroke();

  // Red progress arc (flat edges, same style as source HTML)
  if (percent > 0) {
    const startAngle = -0.5 * Math.PI;
    const endAngle   = startAngle + (percent / 100) * 2 * Math.PI;
    ctx.beginPath();
    ctx.arc(center, center, radius, startAngle, endAngle);
    ctx.lineWidth = strokeWidth;
    ctx.strokeStyle = "#ff3b30";
    ctx.stroke();
  }

  // Center text
  const text = parseFloat(percent.toFixed(2)) + "%";
  ctx.font = `bold ${Math.round(size * 0.18)}px -apple-system, Arial, sans-serif`;
  ctx.fillStyle = "#ff3b30";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, center, center);

  return canvas;
}

$("tts-widget-draw").addEventListener("click", e => {
  e.stopPropagation();
  let val = parseFloat($("tts-widget-num").value);
  if (isNaN(val)) val = 0;
  val = Math.max(0, Math.min(100, val));
  $("tts-widget-num").value = val;

  const canvas = drawWidgetCanvas(val);
  canvas.toBlob(blob => {
    widgetBlob = blob;
    const url = URL.createObjectURL(blob);
    const prev = $("tts-widget-preview");
    prev.src = url;
    prev.style.display = "block";
    const uploadBtn = $("tts-widget-upload");
    uploadBtn.disabled = false;
    uploadBtn.style.background = "#3dba6e";
    uploadBtn.style.color = "#fff";
    uploadBtn.style.border = "none";
    setWidgetStatus(`${val}% — нажми "Загрузить на сайт"`, "ok");
  }, "image/png");
});

$("tts-widget-upload").addEventListener("click", async e => {
  e.stopPropagation();
  if (!widgetBlob) return;
  $("tts-widget-upload").disabled = true;
  setWidgetStatus("Загружаю...");

  try {
    const file = new File([widgetBlob], `widget_${Date.now()}.png`, { type: "image/png" });
    await uploadImageFile(file, setWidgetStatus);
  } finally {
    $("tts-widget-upload").disabled = false;
  }
});

function setWidgetStatus(msg, type = "") {
  const el = $("tts-widget-status"); if (!el) return;
  el.textContent = msg; el.className = "tts-status" + (type ? " " + type : "");
}

// ─── Image upload helper ────────────────────────────────────────────────────────
function realClick(el) {
  // Dispatch a full mouse event sequence — needed for React/Vue div-buttons
  ["mousedown","mouseup","click"].forEach(type => {
    el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
  });
}

function findImageInput() {
  for (const inp of document.querySelectorAll('input[type="file"]')) {
    if (inp.id?.startsWith("tts-")) continue;
    // Prefer inputs that accept images or accept anything
    const acc = (inp.accept || "").toLowerCase();
    if (!acc || acc.includes("image") || acc.includes("*")) return inp;
  }
  return null;
}

function injectIntoInput(inp, file) {
  try {
    const dt = new DataTransfer();
    dt.items.add(file);
    const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "files");
    if (ns?.set) ns.set.call(inp, dt.files);
    inp.dispatchEvent(new Event("input",  { bubbles: true }));
    inp.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  } catch { return false; }
}

async function uploadImageFile(file, statusFn = () => {}) {
  // Strategy 1: file input already in DOM (hidden inside the button wrapper)
  const imgBtn = document.querySelector('[data-testid="add-image-btn"]');
  if (imgBtn) {
    // Check inside the button and its parent tree
    let inp = imgBtn.querySelector('input[type="file"]');
    if (!inp) {
      let el = imgBtn.parentElement;
      for (let i = 0; i < 4 && el; i++, el = el.parentElement) {
        inp = el.querySelector('input[type="file"]:not([id^="tts-"])');
        if (inp) break;
      }
    }
    if (inp) {
      if (injectIntoInput(inp, file)) {
        statusFn("Добавляю...");
        await waitAndClickAddImageBtn(4000);
        statusFn("✅ Загружено!", "ok"); return;
      }
    }
  }

  // Strategy 2: inject into any existing image file input
  const existingInp = findImageInput();
  if (existingInp) {
    if (injectIntoInput(existingInp, file)) {
      statusFn("Добавляю...");
      await waitAndClickAddImageBtn(4000);
      statusFn("✅ Загружено!", "ok"); return;
    }
  }

  // Strategy 3: click the button (real MouseEvent), then wait for file input
  if (imgBtn) {
    statusFn("Открываю диалог...");
    realClick(imgBtn);

    for (let i = 0; i < 20; i++) {
      await new Promise(r => setTimeout(r, 200));
      const inp = findImageInput();
      if (inp && injectIntoInput(inp, file)) {
        statusFn("Добавляю...");
        await waitAndClickAddImageBtn(4000);
        statusFn("✅ Загружено!", "ok");
        return;
      }
    }
  }

  statusFn("Нажми кнопку 🖼 изображения вручную, потом загрузи снова", "warn");
}

async function waitAndClickAddImageBtn(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    await new Promise(r => setTimeout(r, 200));
    // The confirm button is INSIDE the upload-image-modal
    const modal = document.querySelector('[data-testid="upload-image-modal"]');
    if (modal) {
      const btn = modal.querySelector('[data-testid="add-image-btn"]');
      if (btn) { realClick(btn); return true; }
    }
    // Fallback: div inside add_btn row
    const rowBtn = document.querySelector('.popup_add_file_row.add_btn [data-testid="add-image-btn"]');
    if (rowBtn) { realClick(rowBtn); return true; }
  }
  return false;
}

// ─── CALCULATOR TAB ────────────────────────────────────────────────────────────
document.querySelectorAll(".tts-seg-btn").forEach(b => {
  b.addEventListener("click", e => {
    e.stopPropagation();
    calcType = b.dataset.type;
    document.querySelectorAll(".tts-seg-btn").forEach(x => x.classList.toggle("active", x === b));
    runCalc();
  });
});

document.querySelectorAll(".tts-pkg-btn").forEach(b => {
  b.addEventListener("click", e => {
    e.stopPropagation();
    calcPkg = { cr: parseFloat(b.dataset.cr), price: parseFloat(b.dataset.price) };
    document.querySelectorAll(".tts-pkg-btn").forEach(x => x.classList.toggle("active", x === b));
    runCalc();
  });
});

$("tts-calc-val").addEventListener("input", () => runCalc());

function runCalc() {
  const raw = parseFloat($("tts-calc-val").value);
  if (isNaN(raw) || raw < 0) { $("res-cr").textContent = "—"; $("res-bal").textContent = "—"; $("res-price").textContent = "—"; return; }

  let credits, balance, price;
  const ratio = calcPkg.price / calcPkg.cr;

  if (calcType === "credits") {
    credits = raw; balance = credits * 0.056; price = credits * ratio;
  } else if (calcType === "balance") {
    balance = raw; credits = balance / 0.056; price = credits * ratio;
  } else {
    price = raw; credits = price / ratio; balance = credits * 0.056;
  }

  $("res-cr").textContent    = credits.toFixed(2);
  $("res-bal").textContent   = balance.toFixed(2);
  $("res-price").textContent = "$" + price.toFixed(2);
}

// ─── Context menu blur handler ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "CONTEXT_BLUR") {
    handleContextBlur(msg).catch(e => showToast("Ошибка: " + e.message, true));
    return;
  }
  if (msg.type === "CONTEXT_BLUR_ERROR") {
    showToast("Не удалось загрузить: " + msg.error, true); return;
  }
  // Legacy audio inject from popup
  if (msg.type === "UPLOAD_AUDIO") {
    try {
      const bytes = new Uint8Array(msg.bytes);
      const blob  = new Blob([bytes], { type: "audio/mpeg" });
      const file  = new File([blob], msg.filename || "voice.mp3", { type: "audio/mpeg" });
      sendResponse({ ok: injectFile(file) });
    } catch (e) { sendResponse({ ok: false, error: e.message }); }
    return true;
  }
});

async function handleContextBlur({ action, blurLevel, bytes, mimeType, isVideo, srcUrl }) {
  const targetEl = lastRightClickedEl;
  showToast("⏳ Обрабатываю...", false, 30000);

  const sigma = Math.round((blurLevel / 100) * 30); // 25%→8px 50%→15px 75%→23px 100%→30px

  let canvas;
  if (isVideo) {
    canvas = await blurVideoFrame(srcUrl, action, sigma);
  } else {
    const blob = new Blob([new Uint8Array(bytes)], { type: mimeType });
    canvas = await blurImageBlob(blob, action, sigma);
  }

  if (!canvas) { showToast("Не удалось обработать", true); return; }

  // Convert to data URL for in-place replacement
  const dataUrl = await new Promise(r => {
    canvas.toBlob(b => {
      const reader = new FileReader();
      reader.onload = e => r(e.target.result);
      reader.readAsDataURL(b);
    }, "image/png");
  });

  // Replace the element in place on the page
  if (targetEl?.tagName === "IMG") {
    targetEl.src = dataUrl;
    // Remove srcset so browser doesn't override our replacement
    targetEl.removeAttribute("srcset");
    showToast("✅ Фото заменено!", false);
  } else if (targetEl?.tagName === "VIDEO") {
    // Pause video and show blurred frame as poster overlay
    targetEl.pause();
    targetEl.poster = dataUrl;
    // Also create an overlay image on top of the video
    const rect = targetEl.getBoundingClientRect();
    const overlay = document.createElement("img");
    overlay.src = dataUrl;
    overlay.style.cssText = `
      position:fixed;top:${rect.top + window.scrollY}px;left:${rect.left + window.scrollX}px;
      width:${rect.width}px;height:${rect.height}px;
      z-index:99990;object-fit:cover;pointer-events:none;border-radius:4px;
    `;
    overlay.className = "tts-blur-overlay";
    document.body.appendChild(overlay);
    showToast("✅ Видео заменено!", false);
  } else if (targetEl) {
    // Might be a background-image div or similar — try replacing background
    const style = window.getComputedStyle(targetEl);
    if (style.backgroundImage && style.backgroundImage !== "none") {
      targetEl.style.backgroundImage = `url("${dataUrl}")`;
      showToast("✅ Заменено!", false);
    } else {
      showToast("Не удалось найти элемент для замены", true);
    }
  } else {
    showToast("Кликни правой кнопкой прямо на фото", true);
  }
}

async function blurImageBlob(blob, action, sigma = 18) {
  const url = URL.createObjectURL(blob);
  const img = new Image();
  img.src = url;
  await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error("Не удалось загрузить изображение")); });
  URL.revokeObjectURL(url);

  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth; canvas.height = img.naturalHeight;
  const ctx = canvas.getContext("2d");

  const pad = sigma * 2;
  ctx.filter = `blur(${sigma}px)`;
  ctx.drawImage(img, -pad, -pad, canvas.width + pad * 2, canvas.height + pad * 2);
  ctx.filter = "none";

  if (action === "block") drawBlockedOverlay(ctx, canvas.width, canvas.height);
  return canvas;
}

async function blurVideoFrame(srcUrl, action, sigma = 18) {
  let videoEl = null;
  for (const v of document.querySelectorAll("video")) {
    if (v.src === srcUrl || v.currentSrc === srcUrl) { videoEl = v; break; }
  }
  if (!videoEl) videoEl = document.querySelector("video");
  if (!videoEl) return null;

  const canvas = document.createElement("canvas");
  canvas.width = videoEl.videoWidth || 640; canvas.height = videoEl.videoHeight || 360;
  const ctx = canvas.getContext("2d");

  const pad = sigma * 2;
  ctx.filter = `blur(${sigma}px)`;
  ctx.drawImage(videoEl, -pad, -pad, canvas.width + pad * 2, canvas.height + pad * 2);
  ctx.filter = "none";

  if (action === "block") drawBlockedOverlay(ctx, canvas.width, canvas.height);
  return canvas;
}

function drawBlockedOverlay(ctx, w, h) {
  const cx = w / 2, cy = h / 2;
  const scale = Math.min(w, h) * 0.38;

  // Semi-transparent dark overlay
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  ctx.fillRect(0, 0, w, h);

  // Warning triangle
  const tw = scale * 0.88, th = scale * 0.78;
  ctx.beginPath();
  ctx.moveTo(cx, cy - th * 0.55);
  ctx.lineTo(cx - tw / 2, cy + th * 0.45);
  ctx.lineTo(cx + tw / 2, cy + th * 0.45);
  ctx.closePath();
  ctx.strokeStyle = "#ff3b30";
  ctx.lineWidth = Math.max(3, scale * 0.055);
  ctx.lineJoin = "round";
  ctx.stroke();

  // Exclamation mark
  ctx.fillStyle = "#ff3b30";
  ctx.font = `bold ${Math.round(scale * 0.33)}px Arial, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("!", cx, cy + scale * 0.04);

  // "CONTENT BLOCKED" text
  const fs = Math.round(scale * 0.13);
  ctx.font = `bold ${fs}px Arial, sans-serif`;
  ctx.fillText("CONTENT", cx, cy + scale * 0.6);
  ctx.fillText("BLOCKED",  cx, cy + scale * 0.6 + fs * 1.3);
}

setInterval(() => {
  if (!document.getElementById("tts-btn"))   document.body.appendChild(btn);
  if (!document.getElementById("tts-panel")) document.body.appendChild(panel);
}, 1000);
