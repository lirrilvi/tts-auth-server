const MINIMAX_KEY  = "sk-api-gwEUNeu7QBjvnngKiDVDXucEs7my2NAnvmlCGLD4XpM5KBZzGRuhXUwRjjhsYREfkqyQvIsGoy7Kcsg8gr7dXKUf7GTJHFGGZtoBKnbwZ0QP5ZB0NWDk9c0";
const GROUP_ID     = "2024997704433676596";
const AUTH_SERVER  = "https://web-production-054d12.up.railway.app";
const TOKEN_TTL_MS = 12 * 60 * 60 * 1000;

const PRESET_VOICES = [
  { id: "moss_audio_7c5467e5-0fbd-11f1-a2d4-8609e701aa01", name: "Olga" },
  { id: "moss_audio_745e60fa-28b7-11f1-bd1c-42ad608c28be", name: "Mari" },
  { id: "moss_audio_743676dd-1862-11f1-a741-d68e15ebe5cd", name: "Katia" },
  { id: "moss_audio_0490f0b2-27e6-11f1-bd1c-42ad608c28be", name: "Ksenomorph" },
];

let customVoices  = [];
let audioFiles    = [null, null, null];
let panelOpen     = false;
let generatedBlob = null;
let previewAudio  = null;
let isPlaying     = false;

// ─── Styles ───────────────────────────────────────────────────────────────────
const style = document.createElement("style");
style.textContent = `
  #tts-btn {
    position: fixed; top: 8px; right: 200px;
    width: 36px; height: 36px; border-radius: 50%;
    background: #3dba6e; border: none; cursor: pointer;
    z-index: 99999; display: flex; align-items: center; justify-content: center;
    box-shadow: 0 2px 8px rgba(0,0,0,.35);
    transition: background .15s, transform .15s;
    font-size: 17px; line-height: 1; padding: 0;
  }
  #tts-btn:hover { background: #35a860; transform: scale(1.08); }

  #tts-panel {
    position: fixed; top: 52px; right: 14px; width: 310px;
    background: #141414; border: 1px solid #2a2a2a; border-radius: 14px;
    padding: 14px; z-index: 99998;
    box-shadow: 0 8px 32px rgba(0,0,0,.55);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 13px; color: #e8e8e8; display: none;
  }
  #tts-panel * { box-sizing: border-box; margin: 0; padding: 0; }

  .tts-label { display: block; color: #555; font-size: 10px; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 5px; }

  .tts-voice-row { display: flex; gap: 6px; align-items: center; margin-bottom: 10px; }

  #tts-voice-select {
    flex: 1; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #e8e8e8; padding: 7px 28px 7px 10px;
    font-size: 13px; outline: none; cursor: pointer; appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='5'%3E%3Cpath d='M0 0l4.5 5L9 0z' fill='%23555'/%3E%3C/svg%3E");
    background-repeat: no-repeat; background-position: right 9px center;
  }
  #tts-voice-select:focus { border-color: #3dba6e; }

  #tts-btn-add-voice {
    background: transparent; border: 1px solid #2e2e2e; border-radius: 8px;
    color: #3dba6e; padding: 6px 9px; font-size: 11px; cursor: pointer;
    white-space: nowrap; transition: all .15s;
  }
  #tts-btn-add-voice:hover { background: #1a2e22; border-color: #3dba6e; }

  .tts-slider-row { display: flex; align-items: center; gap: 7px; margin-bottom: 7px; }
  .tts-slider-lbl { width: 65px; color: #555; font-size: 11px; flex-shrink: 0; }
  .tts-slider-row input[type=range] { flex: 1; accent-color: #3dba6e; }
  .tts-slider-val { width: 30px; text-align: right; color: #888; font-size: 11px; font-variant-numeric: tabular-nums; }

  #tts-textarea {
    width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #e8e8e8; font-size: 13px;
    padding: 8px 10px; resize: vertical; min-height: 72px;
    outline: none; margin-bottom: 9px; font-family: inherit; line-height: 1.5;
  }
  #tts-textarea:focus { border-color: #3dba6e; }
  #tts-textarea::placeholder { color: #333; }

  #tts-btn-speak {
    width: 100%; background: #3dba6e; color: #fff; border: none;
    border-radius: 8px; padding: 9px; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: background .15s; margin-bottom: 8px;
  }
  #tts-btn-speak:hover { background: #35a860; }
  #tts-btn-speak:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }

  #tts-player {
    display: none; background: #0f0f0f; border: 1px solid #222;
    border-radius: 10px; padding: 10px 12px; margin-bottom: 8px;
  }
  #tts-player-label { font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 8px; }

  #tts-progress-wrap {
    position: relative; height: 3px; background: #222;
    border-radius: 2px; margin-bottom: 8px; cursor: pointer;
  }
  #tts-progress-bar { height: 100%; background: #3dba6e; border-radius: 2px; width: 0%; pointer-events: none; }

  #tts-time { font-size: 10px; color: #555; margin-bottom: 8px; font-variant-numeric: tabular-nums; }

  .tts-player-btns { display: flex; gap: 6px; }

  #tts-btn-play {
    flex: 1; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 7px; color: #e8e8e8; font-size: 12px;
    padding: 7px; cursor: pointer; transition: all .15s;
  }
  #tts-btn-play:hover { background: #242424; }

  #tts-btn-redo {
    flex: 1; background: transparent; border: 1px solid #2e2e2e;
    border-radius: 7px; color: #888; font-size: 12px;
    padding: 7px; cursor: pointer; transition: all .15s;
  }
  #tts-btn-redo:hover { border-color: #555; color: #ccc; }

  #tts-btn-upload {
    flex: 1.5; background: #3dba6e; border: none;
    border-radius: 7px; color: #fff; font-size: 12px; font-weight: 600;
    padding: 7px; cursor: pointer; transition: background .15s;
  }
  #tts-btn-upload:hover { background: #35a860; }
  #tts-btn-upload:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }

  #tts-status { font-size: 11px; color: #444; min-height: 15px; margin-top: 6px; text-align: center; }
  #tts-status.ok    { color: #3dba6e; }
  #tts-status.error { color: #e05555; }
  #tts-status.warn  { color: #c8a020; }

  #tts-auth-screen {
    display: none; text-align: center; padding: 6px 0 2px;
  }
  #tts-auth-screen p { font-size: 12px; color: #888; margin-bottom: 10px; line-height: 1.5; }
  #tts-auth-screen a { color: #3dba6e; }
  #tts-token-input {
    width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e;
    border-radius: 8px; color: #e8e8e8; font-size: 15px; font-weight: 600;
    padding: 8px 10px; outline: none; text-align: center;
    letter-spacing: 2px; text-transform: uppercase; margin-bottom: 8px;
    font-family: monospace;
  }
  #tts-token-input:focus { border-color: #3dba6e; }
  #tts-token-input::placeholder { font-weight: 400; letter-spacing: 0; font-size: 12px; text-transform: none; color: #333; }
  #tts-btn-auth {
    width: 100%; background: #3dba6e; color: #fff; border: none;
    border-radius: 8px; padding: 9px; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: background .15s;
  }
  #tts-btn-auth:hover { background: #35a860; }
  #tts-btn-auth:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }
  #tts-auth-status { font-size: 11px; margin-top: 6px; min-height: 14px; }
  #tts-auth-status.error { color: #e05555; }
  #tts-auth-status.ok    { color: #3dba6e; }
  #tts-token-info {
    font-size: 10px; color: #3dba6e; text-align: right;
    margin-bottom: 6px; display: none;
  }

  .tts-divider { border: none; border-top: 1px solid #1e1e1e; margin: 10px 0; }

  #tts-add-panel { background: #0f0f0f; border: 1px solid #222; border-radius: 10px; padding: 11px; margin-bottom: 10px; display: none; }
  #tts-add-panel h3 { font-size: 12px; font-weight: 600; color: #bbb; margin-bottom: 9px; }
  #tts-voice-name { width: 100%; background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 7px; color: #e8e8e8; font-size: 12px; padding: 6px 9px; outline: none; margin-bottom: 8px; font-family: inherit; }
  #tts-voice-name:focus { border-color: #3dba6e; }
  #tts-voice-name::placeholder { color: #333; }
  .tts-file-slot { display: flex; align-items: center; gap: 7px; margin-bottom: 5px; }
  .tts-slot-num { width: 18px; height: 18px; border-radius: 50%; background: #1e1e1e; border: 1px solid #2e2e2e; color: #555; font-size: 9px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .tts-slot-num.done { background: #1a3a2a; border-color: #3dba6e; color: #3dba6e; }
  .tts-slot-lbl { flex: 1; color: #444; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tts-slot-lbl.filled { color: #999; }
  .tts-slot-pick { background: #1c1c1c; border: 1px solid #2e2e2e; border-radius: 6px; color: #777; font-size: 10px; padding: 3px 7px; cursor: pointer; flex-shrink: 0; }
  .tts-slot-pick:hover { background: #242424; color: #bbb; }
  .tts-clone-hint { font-size: 10px; color: #333; margin: 6px 0 8px; line-height: 1.4; }
  .tts-panel-btns { display: flex; gap: 5px; }
  .tts-btn-cancel { flex: 1; background: transparent; border: 1px solid #2e2e2e; border-radius: 7px; color: #555; font-size: 11px; padding: 7px; cursor: pointer; }
  .tts-btn-cancel:hover { color: #999; border-color: #444; }
  .tts-btn-clone { flex: 2; background: #3dba6e; border: none; border-radius: 7px; color: #fff; font-size: 11px; font-weight: 600; padding: 7px; cursor: pointer; }
  .tts-btn-clone:hover { background: #35a860; }
  .tts-btn-clone:disabled { background: #1e4d35; color: #3a3a3a; cursor: default; }
`;
document.head.appendChild(style);

// ─── Toggle button ─────────────────────────────────────────────────────────────
const btn = document.createElement("button");
btn.id = "tts-btn"; btn.title = "TTS Voice"; btn.innerHTML = "🗣";
document.body.appendChild(btn);

// ─── Panel ─────────────────────────────────────────────────────────────────────
const panel = document.createElement("div");
panel.id = "tts-panel";
panel.innerHTML = `
  <!-- Экран авторизации -->
  <div id="tts-auth-screen">
    <p>🔐 Введи код из Telegram-бота<br><small style="color:#555">Получи /token у бота</small></p>
    <input type="text" id="tts-token-input" placeholder="Введи код (напр. A3B7XK2P)" maxlength="12">
    <button id="tts-btn-auth">Войти</button>
    <div id="tts-auth-status"></div>
  </div>

  <!-- Основной интерфейс -->
  <div id="tts-main">
  <div id="tts-token-info"></div>
  <span class="tts-label">Голос</span>
  <div class="tts-voice-row">
    <select id="tts-voice-select"></select>
    <button id="tts-btn-add-voice">+ Add</button>
  </div>

  <div id="tts-add-panel">
    <h3>🎤 Новый голос</h3>
    <input type="text" id="tts-voice-name" placeholder="Название (напр. Alex)">
    <div id="tts-file-slots"></div>
    <p class="tts-clone-hint">MP3 / WAV · 15–30 сек · говорите чётко</p>
    <div class="tts-panel-btns">
      <button class="tts-btn-cancel" id="tts-cancel-clone">Отмена</button>
      <button class="tts-btn-clone" id="tts-do-clone" disabled>Создать голос</button>
    </div>
  </div>

  <hr class="tts-divider">

  <div class="tts-slider-row">
    <span class="tts-slider-lbl">Скорость</span>
    <input type="range" id="tts-speed" min="0.5" max="2.0" step="0.1" value="1.0">
    <span class="tts-slider-val" id="tts-speed-val">1.0x</span>
  </div>
  <div class="tts-slider-row">
    <span class="tts-slider-lbl">Громкость</span>
    <input type="range" id="tts-volume" min="0.2" max="3.0" step="0.1" value="1.0">
    <span class="tts-slider-val" id="tts-vol-val">1.0</span>
  </div>

  <hr class="tts-divider">

  <textarea id="tts-textarea" placeholder="Введите текст для озвучки..."></textarea>
  <button id="tts-btn-speak">▶ Сгенерировать</button>

  <div id="tts-player">
    <div id="tts-player-label">Превью</div>
    <div id="tts-progress-wrap"><div id="tts-progress-bar"></div></div>
    <div id="tts-time">0:00 / 0:00</div>
    <div class="tts-player-btns">
      <button id="tts-btn-play">▶ Слушать</button>
      <button id="tts-btn-redo">🔄 Заново</button>
      <button id="tts-btn-upload">⬆ Загрузить</button>
    </div>
  </div>

  <div id="tts-status"></div>
  </div><!-- #tts-main -->
`;
document.body.appendChild(panel);

// ─── Hidden file inputs for voice cloning ──────────────────────────────────────
const fileInputs = [0,1,2].map(i => {
  const inp = document.createElement("input");
  inp.type = "file"; inp.accept = "audio/*";
  inp.style.display = "none"; inp.id = `tts-file-${i}`;
  document.body.appendChild(inp);
  return inp;
});

const $ = id => document.getElementById(id);

// ─── Init ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get(["voiceId","speed","volume","lastText","customVoices"], data => {
  customVoices = data.customVoices || [];
  renderVoices();
  if (data.voiceId)  $("tts-voice-select").value = data.voiceId;
  if (data.speed)   { $("tts-speed").value = data.speed;  $("tts-speed-val").textContent  = parseFloat(data.speed).toFixed(1)+"x"; }
  if (data.volume)  { $("tts-volume").value = data.volume; $("tts-vol-val").textContent   = parseFloat(data.volume).toFixed(1); }
  if (data.lastText) $("tts-textarea").value = data.lastText;
});

buildFileSlots();

// ─── Auth ──────────────────────────────────────────────────────────────────────
function showAuthScreen() {
  $("tts-auth-screen").style.display = "block";
  $("tts-main").style.display = "none";
}
function showMainScreen() {
  $("tts-auth-screen").style.display = "none";
  $("tts-main").style.display = "block";
}

async function checkAuth() {
  const { ttsToken, ttsTokenExpiry } = await new Promise(r =>
    chrome.storage.local.get(["ttsToken","ttsTokenExpiry"], r)
  );
  if (ttsToken && ttsTokenExpiry && Date.now() < ttsTokenExpiry) {
    showMainScreen();
    const left = Math.round((ttsTokenExpiry - Date.now()) / 3600000);
    const info = $("tts-token-info");
    info.style.display = "block";
    info.textContent = `🔑 Токен действует ~${left}ч`;
  } else {
    chrome.storage.local.remove(["ttsToken","ttsTokenExpiry"]);
    showAuthScreen();
  }
}

$("tts-btn-auth").addEventListener("click", async e => {
  e.stopPropagation();
  const token = $("tts-token-input").value.trim().toUpperCase();
  if (!token) return;

  $("tts-btn-auth").disabled = true;
  $("tts-auth-status").textContent = "Проверяю...";
  $("tts-auth-status").className = "";

  try {
    const res  = await fetch(`${AUTH_SERVER}/api/validate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token })
    });
    const data = await res.json();

    if (data.ok) {
      const expiry = Date.now() + TOKEN_TTL_MS;
      await new Promise(r => chrome.storage.local.set({ ttsToken: token, ttsTokenExpiry: expiry }, r));
      $("tts-auth-status").textContent = "✓ " + (data.expires_msg || "Авторизован");
      $("tts-auth-status").className = "ok";
      setTimeout(() => { showMainScreen(); checkAuth(); }, 800);
    } else {
      $("tts-auth-status").textContent = data.msg || "Неверный токен";
      $("tts-auth-status").className = "error";
      $("tts-btn-auth").disabled = false;
    }
  } catch {
    $("tts-auth-status").textContent = "Сервер недоступен";
    $("tts-auth-status").className = "error";
    $("tts-btn-auth").disabled = false;
  }
});

$("tts-token-input").addEventListener("keydown", e => { if (e.key === "Enter") $("tts-btn-auth").click(); });

// ─── Toggle panel ──────────────────────────────────────────────────────────────
btn.addEventListener("click", () => {
  panelOpen = !panelOpen;
  panel.style.display = panelOpen ? "block" : "none";
  if (panelOpen) checkAuth();
});

document.addEventListener("click", e => {
  if (panelOpen && !panel.contains(e.target) && e.target !== btn) {
    panelOpen = false;
    panel.style.display = "none";
  }
});

// ─── Voices ────────────────────────────────────────────────────────────────────
function renderVoices() {
  const sel = $("tts-voice-select");
  sel.innerHTML = "";
  for (const v of PRESET_VOICES) {
    const o = document.createElement("option");
    o.value = v.id; o.textContent = v.name;
    sel.appendChild(o);
  }
  if (customVoices.length) {
    const sep = document.createElement("option");
    sep.disabled = true; sep.textContent = "── Мои голоса ──";
    sel.appendChild(sep);
    for (const cv of customVoices) {
      const o = document.createElement("option");
      o.value = cv.id; o.textContent = "👤 " + cv.name;
      sel.appendChild(o);
    }
  }
}

$("tts-voice-select").addEventListener("change", () => chrome.storage.local.set({ voiceId: $("tts-voice-select").value }));

// ─── Add voice panel ───────────────────────────────────────────────────────────
$("tts-btn-add-voice").addEventListener("click", e => {
  e.stopPropagation();
  const ap = $("tts-add-panel");
  ap.style.display = ap.style.display === "none" ? "block" : "none";
});
$("tts-cancel-clone").addEventListener("click", () => { resetClone(); $("tts-add-panel").style.display = "none"; });

function buildFileSlots() {
  const container = $("tts-file-slots");
  if (!container) return;
  container.innerHTML = "";
  for (let i = 0; i < 3; i++) {
    const slot = document.createElement("div");
    slot.className = "tts-file-slot";
    slot.innerHTML = `
      <div class="tts-slot-num" id="tts-num-${i}">${i+1}</div>
      <span class="tts-slot-lbl" id="tts-lbl-${i}">Аудио #${i+1}</span>
      <button class="tts-slot-pick" data-slot="${i}">Выбрать</button>`;
    container.appendChild(slot);
    slot.querySelector(".tts-slot-pick").addEventListener("click", e => { e.stopPropagation(); fileInputs[i].click(); });
    fileInputs[i].addEventListener("change", () => {
      const f = fileInputs[i].files[0]; if (!f) return;
      audioFiles[i] = f;
      $(`tts-lbl-${i}`).textContent = f.name; $(`tts-lbl-${i}`).className = "tts-slot-lbl filled";
      $(`tts-num-${i}`).className = "tts-slot-num done";
      updateCloneBtn();
    });
  }
}

$("tts-voice-name").addEventListener("input", updateCloneBtn);
function updateCloneBtn() {
  $("tts-do-clone").disabled = !(audioFiles.every(f => f !== null) && $("tts-voice-name").value.trim().length > 0);
}
function resetClone() {
  audioFiles = [null, null, null]; $("tts-voice-name").value = "";
  for (let i = 0; i < 3; i++) {
    $(`tts-lbl-${i}`).textContent = `Аудио #${i+1}`; $(`tts-lbl-${i}`).className = "tts-slot-lbl";
    $(`tts-num-${i}`).className = "tts-slot-num"; fileInputs[i].value = "";
  }
  $("tts-do-clone").disabled = true;
}

$("tts-do-clone").addEventListener("click", async e => {
  e.stopPropagation();
  const voiceName = $("tts-voice-name").value.trim();
  if (!voiceName || audioFiles.some(f => !f)) return;

  $("tts-do-clone").disabled = true;
  setStatus("Объединяю аудио...");

  try {
    const buffers = await Promise.all(audioFiles.map(f => f.arrayBuffer()));
    const total = buffers.reduce((s, b) => s + b.byteLength, 0);
    const merged = new Uint8Array(total);
    let offset = 0;
    for (const buf of buffers) { merged.set(new Uint8Array(buf), offset); offset += buf.byteLength; }
    const mergedBlob = new Blob([merged], { type: "audio/mpeg" });

    setStatus("Загружаю на MiniMax...");
    const form = new FormData();
    form.append("file", mergedBlob, `clone_${Date.now()}.mp3`);
    form.append("purpose", "voice_clone");

    const upRes  = await fetch(`https://api.minimax.io/v1/files/upload?GroupId=${GROUP_ID}`, {
      method: "POST", headers: { "Authorization": `Bearer ${MINIMAX_KEY}` }, body: form
    });
    const upData = await upRes.json();
    if (!upData?.file?.file_id) throw new Error("Ошибка загрузки: " + JSON.stringify(upData));

    setStatus("Создаю голос...");
    const voiceId = `cv_ext_${Date.now()}`;
    const clRes = await fetch(`https://api.minimax.io/v1/voice_clone?GroupId=${GROUP_ID}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${MINIMAX_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ file_id: upData.file.file_id, voice_id: voiceId })
    });
    const clData = await clRes.json();
    if (!clRes.ok && !clData?.base_resp) throw new Error("Ошибка клонирования: " + JSON.stringify(clData));

    customVoices.push({ name: voiceName, id: voiceId });
    chrome.storage.local.set({ customVoices });
    renderVoices();
    $("tts-voice-select").value = voiceId;
    chrome.storage.local.set({ voiceId });
    setStatus(`Голос "${voiceName}" создан!`, "ok");
    resetClone();
    $("tts-add-panel").style.display = "none";
  } catch (err) {
    setStatus("Ошибка: " + err.message, "error");
    $("tts-do-clone").disabled = false;
  }
});

// ─── Sliders ───────────────────────────────────────────────────────────────────
$("tts-speed").addEventListener("input", () => {
  const v = parseFloat($("tts-speed").value).toFixed(1);
  $("tts-speed-val").textContent = v + "x";
  chrome.storage.local.set({ speed: v });
});
$("tts-volume").addEventListener("input", () => {
  const v = parseFloat($("tts-volume").value).toFixed(1);
  $("tts-vol-val").textContent = v;
  chrome.storage.local.set({ volume: v });
});
$("tts-textarea").addEventListener("input", () => chrome.storage.local.set({ lastText: $("tts-textarea").value }));

// ─── Generate via API ──────────────────────────────────────────────────────────
$("tts-btn-speak").addEventListener("click", e => { e.stopPropagation(); doGenerate(); });
$("tts-btn-redo").addEventListener("click",  e => { e.stopPropagation(); doGenerate(); });

async function doGenerate() {
  const text = $("tts-textarea").value.trim();
  if (!text) { setStatus("Введите текст", "error"); return; }

  stopPreview();
  $("tts-player").style.display = "none";
  $("tts-btn-speak").disabled = true;
  setStatus("Генерирую аудио...");

  try {
    const speed   = parseFloat($("tts-speed").value);
    const vol     = parseFloat($("tts-volume").value);
    const voiceId = $("tts-voice-select").value;

    const res = await fetch(`https://api.minimax.io/v1/t2a_v2?GroupId=${GROUP_ID}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${MINIMAX_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "speech-01-turbo",
        text,
        stream: false,
        voice_setting: {
          voice_id: voiceId,
          speed: Math.round(speed * 10) / 10,
          vol:   Math.round(vol   * 10) / 10,
          pitch: 0
        },
        audio_setting: { sample_rate: 32000, bitrate: 128000, format: "mp3", channel: 1 }
      })
    });

    const data = await res.json();
    if (data?.base_resp?.status_code !== 0) throw new Error(data?.base_resp?.status_msg || "Ошибка API");

    const hexAudio = data?.data?.audio;
    if (!hexAudio) throw new Error("Нет аудио в ответе");

    const bytes = new Uint8Array(hexAudio.match(/.{1,2}/g).map(b => parseInt(b, 16)));
    generatedBlob = new Blob([bytes], { type: "audio/mpeg" });

    setStatus("Готово — прослушай перед загрузкой", "ok");
    showPlayer();
  } catch (err) {
    setStatus("Ошибка: " + err.message, "error");
  } finally {
    $("tts-btn-speak").disabled = false;
  }
}

// ─── Preview player ────────────────────────────────────────────────────────────
function showPlayer() {
  $("tts-player").style.display = "block";
  $("tts-progress-bar").style.width = "0%";
  $("tts-time").textContent = "0:00 / 0:00";
  updatePlayBtn(false);
}

function updatePlayBtn(playing) {
  isPlaying = playing;
  $("tts-btn-play").textContent = playing ? "⏸ Пауза" : "▶ Слушать";
}

function formatTime(s) {
  return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`;
}

function stopPreview() {
  if (previewAudio) { previewAudio.pause(); previewAudio.src = ""; previewAudio = null; }
  isPlaying = false;
}

$("tts-btn-play").addEventListener("click", e => {
  e.stopPropagation();
  if (!generatedBlob) return;

  if (isPlaying && previewAudio) { previewAudio.pause(); updatePlayBtn(false); return; }
  if (previewAudio && previewAudio.paused) { previewAudio.play(); updatePlayBtn(true); return; }

  previewAudio = new Audio(URL.createObjectURL(generatedBlob));
  previewAudio.addEventListener("timeupdate", () => {
    if (!previewAudio?.duration) return;
    $("tts-progress-bar").style.width = (previewAudio.currentTime / previewAudio.duration * 100) + "%";
    $("tts-time").textContent = `${formatTime(previewAudio.currentTime)} / ${formatTime(previewAudio.duration)}`;
  });
  previewAudio.addEventListener("ended", () => { updatePlayBtn(false); $("tts-progress-bar").style.width = "0%"; });
  previewAudio.addEventListener("error",  () => { setStatus("Ошибка воспроизведения", "error"); updatePlayBtn(false); });
  previewAudio.play();
  updatePlayBtn(true);
});

$("tts-progress-wrap").addEventListener("click", e => {
  if (!previewAudio?.duration) return;
  const rect = $("tts-progress-wrap").getBoundingClientRect();
  previewAudio.currentTime = ((e.clientX - rect.left) / rect.width) * previewAudio.duration;
});

// ─── Upload ────────────────────────────────────────────────────────────────────
$("tts-btn-upload").addEventListener("click", async e => {
  e.stopPropagation();
  if (!generatedBlob) return;

  stopPreview();
  $("tts-btn-upload").disabled = true;
  setStatus("Загружаю...");

  try {
    const file = new File([generatedBlob], `voice_${Date.now()}.mp3`, { type: "audio/mpeg" });

    if (injectFile(file)) { setStatus("Файл загружен!", "ok"); return; }

    const audioBtn = findAudioButton();
    if (audioBtn) {
      audioBtn.click();
      setStatus("Жду открытия модала...");
      const ok = await waitAndInject(file, 3000);
      setStatus(ok ? "Файл загружен!" : "Открой модал загрузки аудио вручную", ok ? "ok" : "warn");
    } else {
      setStatus("Нажми кнопку AUDIO на сайте, потом загрузи снова", "warn");
    }
  } finally {
    $("tts-btn-upload").disabled = false;
  }
});

function findAudioButton() {
  for (const el of document.querySelectorAll("button, div, span, a")) {
    const txt = (el.innerText || el.textContent || "").trim().toUpperCase();
    if (txt === "AUDIO" && el.offsetParent !== null) return el;
  }
  return null;
}

async function waitAndInject(file, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    await new Promise(r => setTimeout(r, 200));
    if (injectFile(file)) return true;
  }
  return false;
}

function injectFile(file) {
  const inputs = Array.from(document.querySelectorAll('input[type="file"]'))
    .filter(inp => !inp.id.startsWith("tts-"));

  for (const inp of inputs) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "files");
      if (ns?.set) ns.set.call(inp, dt.files);
      inp.dispatchEvent(new Event("input",  { bubbles: true }));
      inp.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (_) {}
  }

  for (const el of document.querySelectorAll("*")) {
    const txt = (el.innerText || "").trim();
    if ((txt.includes("Drag & drop") || txt.includes("drag & drop")) && txt.length < 200) {
      const dt = new DataTransfer(); dt.items.add(file);
      for (const name of ["dragenter","dragover","drop"]) {
        const ev = new DragEvent(name, { bubbles: true, cancelable: true });
        Object.defineProperty(ev, "dataTransfer", { value: dt });
        el.dispatchEvent(ev);
      }
      return true;
    }
  }
  return false;
}

function setStatus(msg, type = "") {
  const el = $("tts-status");
  if (!el) return;
  el.textContent = msg;
  el.className = type;
}

// ─── Messages from popup ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "UPLOAD_AUDIO") return;
  try {
    const bytes = new Uint8Array(msg.bytes);
    const blob  = new Blob([bytes], { type: "audio/mpeg" });
    const file  = new File([blob], msg.filename || "voice.mp3", { type: "audio/mpeg" });
    sendResponse({ ok: injectFile(file) });
  } catch (e) { sendResponse({ ok: false, error: e.message }); }
  return true;
});
