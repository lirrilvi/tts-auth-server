// ─── Context menu: blur images/videos ────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  // Parent: blur
  chrome.contextMenus.create({ id: "tts-blur", title: "🔵 Размыть фото/видео", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-blur-25",  title: "25% — лёгкое",  parentId: "tts-blur", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-blur-50",  title: "50% — среднее", parentId: "tts-blur", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-blur-75",  title: "75% — сильное", parentId: "tts-blur", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-blur-100", title: "100% — полное",  parentId: "tts-blur", contexts: ["image", "video"] });

  // Parent: blur + blocked
  chrome.contextMenus.create({ id: "tts-block", title: "🚫 Размыть + BLOCKED", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-block-25",  title: "25% — лёгкое",  parentId: "tts-block", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-block-50",  title: "50% — среднее", parentId: "tts-block", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-block-75",  title: "75% — сильное", parentId: "tts-block", contexts: ["image", "video"] });
  chrome.contextMenus.create({ id: "tts-block-100", title: "100% — полное",  parentId: "tts-block", contexts: ["image", "video"] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId;
  // Only handle leaf items (with blur level)
  if (!id.match(/-(25|50|75|100)$/)) return;
  const action = id.startsWith("tts-block") ? "block" : "blur";
  const blurLevel = parseInt(id.match(/(\d+)$/)[1]); // 25 / 50 / 75 / 100

  if (info.mediaType === "video") {
    chrome.tabs.sendMessage(tab.id, { type: "CONTEXT_BLUR", action, blurLevel, srcUrl: info.srcUrl, isVideo: true });
    return;
  }

  try {
    const resp = await fetch(info.srcUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const buffer = await resp.arrayBuffer();
    const bytes = Array.from(new Uint8Array(buffer));
    const mimeType = resp.headers.get("content-type") || "image/jpeg";
    chrome.tabs.sendMessage(tab.id, { type: "CONTEXT_BLUR", action, blurLevel, bytes, mimeType, isVideo: false });
  } catch (e) {
    chrome.tabs.sendMessage(tab.id, { type: "CONTEXT_BLUR_ERROR", error: e.message });
  }
});

// ─── TTS generation via minimax.io tab ────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GENERATE_TTS") {
    handleGenerateTTS(msg).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
});

async function handleGenerateTTS({ text, voiceId, speed, vol }) {
  let tabs = await chrome.tabs.query({ url: ["https://www.minimax.io/*", "https://minimax.io/*"] });
  let tab = tabs[0];

  if (!tab) {
    tab = await chrome.tabs.create({ url: "https://www.minimax.io/audio/text-to-speech", active: false });
    await new Promise(resolve => {
      function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      }
      chrome.tabs.onUpdated.addListener(listener);
    });
    await new Promise(r => setTimeout(r, 2500));
  }

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Таймаут 35с — зайди на minimax.io и сгенерируй аудио хотя бы раз")), 35000);
    chrome.tabs.sendMessage(tab.id, { type: "MINIMAX_GENERATE", text, voiceId, speed, vol }, response => {
      clearTimeout(timeout);
      if (chrome.runtime.lastError) reject(new Error("Ошибка связи с minimax.io: " + chrome.runtime.lastError.message));
      else if (response?.error) reject(new Error(response.error));
      else resolve(response);
    });
  });
}
