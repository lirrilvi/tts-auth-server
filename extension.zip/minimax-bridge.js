// MAIN world on minimax.io
// 1. Intercepts WebSocket URL → posts to isolated world for storage
// 2. Handles TTS generation requests relayed from isolated world

(function () {
  const OrigWS = window.WebSocket;
  let lastWsUrl = null;

  window.WebSocket = function (url, protocols) {
    if (typeof url === "string" && url.includes("minimax.io/v1/api/audio/ws")) {
      lastWsUrl = url;
      window.postMessage({ type: "TTS_EXT_WS_URL", url }, "*");
    }
    return protocols ? new OrigWS(url, protocols) : new OrigWS(url);
  };
  window.WebSocket.prototype  = OrigWS.prototype;
  window.WebSocket.CONNECTING = OrigWS.CONNECTING;
  window.WebSocket.OPEN       = OrigWS.OPEN;
  window.WebSocket.CLOSING    = OrigWS.CLOSING;
  window.WebSocket.CLOSED     = OrigWS.CLOSED;

  // Listen for generation requests from isolated world
  window.addEventListener("message", event => {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== "TTS_EXT_GENERATE") return;

    const { text, voiceId, speed, vol, requestId } = event.data;

    if (!lastWsUrl) {
      window.postMessage({ type: "TTS_EXT_AUDIO", requestId, error: "Нет WS URL — нажми Generate на minimax.io хотя бы раз" }, "*");
      return;
    }

    generateAudio(lastWsUrl, text, voiceId, speed, vol)
      .then(hexAudio => window.postMessage({ type: "TTS_EXT_AUDIO", requestId, hexAudio }, "*"))
      .catch(e => window.postMessage({ type: "TTS_EXT_AUDIO", requestId, error: e.message }, "*"));
  });

  function generateAudio(wsUrl, text, voiceId, speed, vol) {
    return new Promise((resolve, reject) => {
      let ws;
      try { ws = new OrigWS(wsUrl); }
      catch (e) { return reject(new Error("Ошибка подключения: " + e.message)); }

      const chunks = [];
      const msgId  = (typeof crypto !== "undefined" && crypto.randomUUID) ? crypto.randomUUID() : Math.random().toString(36).slice(2);
      let   done   = false;

      const timer = setTimeout(() => {
        ws.close();
        lastWsUrl = null; // force recapture next time
        reject(new Error("Таймаут — нажми Generate на minimax.io для обновления сессии"));
      }, 30000);

      ws.onopen = () => {
        console.log("[TTS-EXT] WS открыт, отправляю запрос, voice_id:", voiceId);
        ws.send(JSON.stringify({
          msg_id: msgId,
          payload: {
            audio_setting: {},
            effects: { deepen_lighten: 0, stronger_softer: 0, nasal_crisp: 0, spacious_echo: false, lofi_telephone: false },
            er_weights: [],
            language_boost: "Auto",
            model: "speech-2.8-hd",
            stream: true,
            text,
            voice_setting: { speed: Math.round(speed * 10) / 10, vol: Math.round(vol * 10) / 10, pitch: 0, voice_id: voiceId }
          }
        }));
      };

      ws.onmessage = event => {
        console.log("[TTS-EXT] сообщение от сервера:", typeof event.data === "string" ? event.data.substring(0, 300) : "[binary]");
        try {
          const msg = JSON.parse(event.data);
          if (msg.method === "Heartbeat") return;

          // Handle both response formats
          if (msg.base_resp && msg.base_resp.status_code !== 0) {
            clearTimeout(timer); ws.close(); done = true;
            return reject(new Error(msg.base_resp.status_msg || "Ошибка MiniMax"));
          }
          if (msg.statusInfo && msg.statusInfo.code !== 0) {
            clearTimeout(timer); ws.close(); done = true;
            return reject(new Error("Ошибка сервера " + msg.statusInfo.code + ": " + (msg.statusInfo.message || "voice_id не поддерживается сайтом")));
          }

          if (msg.data?.audio) chunks.push(msg.data.audio);

          if (msg.data?.extra_info !== undefined && !done) {
            done = true; clearTimeout(timer); ws.close();
            if (chunks.length === 0) return reject(new Error("Нет аудио — voice_id не поддерживается"));
            resolve(chunks.join(""));
          }
        } catch (_) {}
      };

      ws.onerror = (e) => {
        console.log("[TTS-EXT] WS onerror:", e.type);
        clearTimeout(timer);
        lastWsUrl = null;
        reject(new Error("WS ошибка — нажми Generate на minimax.io для обновления сессии"));
      };

      ws.onclose = (ev) => {
        console.log("[TTS-EXT] WS onclose: code=" + ev.code + " reason=" + ev.reason + " done=" + done);
        clearTimeout(timer);
        if (!done) {
          lastWsUrl = null;
          reject(new Error("Сессия истекла (code=" + ev.code + ") — нажми Generate на minimax.io"));
        }
      };
    });
  }
})();
